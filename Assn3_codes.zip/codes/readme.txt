using the PyCharm and python3.6

the code in ECS machine:
PyCharm 2019.1.3 (Professional Edition)
Build #PY-191.7479.30, built on May 30, 2019
Licensed to Aaron Lee
Subscription is active until August 14, 2020
For educational use only.
JRE: 11.0.2+9-b159.60 amd64
JVM: OpenJDK 64-Bit Server VM by JetBrains s.r.o
Windows 10 10.0


the code file includes 4 files:
1. fraud_detection_merge.py: 
using the merge the train_transaction and train_identity to train_merge.csv.
using the merge the test_transaction and test_identity to test_merge.csv.

2.fraud_detection_xGboosting.py
the frist system: using XGBoosting.XGBClassifier

3. fraud_detection_LGBM.py
LGBM.LGBMClassifier    model

4.fraud_detection_Final.py
LGBM.LGBMClassifier    model  + some arbitrary features interaction  +new columns to find the feature interaction  _year
