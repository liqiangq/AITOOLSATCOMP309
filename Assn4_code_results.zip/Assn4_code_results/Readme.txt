Baselines requires python3 (>=3.6) with the development headers.

the files in detail:
1. data in data files;
2. utilities have used in the losses,optimizers and visualization function codes;
3. the codes includes four parts(part1,part2,part3_1,part3_2);
4. the samples_plots have the results of  three parts codes;

